The contents of this folder include training data, model parameters, and log information, which can be automatically
generated using code, without the need for any input information other than the **formalgeo7k_v1** dataset. It is
important to note that:

1.We manually changed `α` to `a` in approximately 5 problems when using **formalgeo7k_v1** to generate training data.
Because our vocabulary does not contain `α`. Apart from this, there are no other changes. Therefore, we provide the
generated data, so users do not need to regenerate it.

2.The parameters of all models are about 850MB in size, and uploading them to GitHub would not be advisable. You can
follow the instructions in the `README.md` to complete the full training steps and obtain the trained model. If you
prefer to directly obtain the model parameters we trained, email xiaokaizhang1999@163.com.

3.Forward search log data in `data/log/evaluation` comes from project [FGPS](https://github.com/BitSecret/FGPS). We only
selected questions from the testing set to calculate the evaluation results. In this paper, the timeout is set to 30
seconds. Therefore, we consider those problems that are solved successfully but take more than 30 seconds as timeouts.